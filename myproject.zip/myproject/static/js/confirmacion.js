/*function confirmarEliminacion(id) {
    Swal.fire({
        title: 'Estas seguro que deseas eliminar este post?',
        text: "No podrás revertir los cambios!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: 'Cancelar',
        confirmButtonText: 'Si, eliminar!'
      }).then((result) => {
        if (result.isConfirmed) {
         window.location.href = "/post_list/";
            
        }
      })   
}*/